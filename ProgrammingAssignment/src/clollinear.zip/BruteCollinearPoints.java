import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.ArrayList;
import java.util.Arrays;

public class BruteCollinearPoints {
	private final Point[] points;
	private int num;
	private final ArrayList<LineSegment> lineList;

	/*
	* Test 14: Check that the constructor throws an exception if duplicate points
	* */
 	 public BruteCollinearPoints(Point[] p)    // finds all line segments containing 4 points
	 {
 		 if(p == null) throw new java.lang.NullPointerException();
		 num = p.length;
		 this.points = new Point[num];

		 for(int i = 0; i< num; i++){
			 if(p[i] == null)
				 throw new java.lang.NullPointerException();
			 points[i] = p[i];
		 }

		 Arrays.sort(points);
		 for(int i = 1; i< num; i++){
			 if(points[i].compareTo(points[i-1])==0)
				 throw new java.lang.IllegalArgumentException();			 
		 }

		 lineList = new ArrayList<LineSegment>();
		 double iToj,iTok,iTol;
		 for(int i = 0; i< num; i++){//i j k l
			 for(int j = i+1; j< num; j++){
				 for(int k = j+1; k< num; k++){
					 for(int l = k+1; l< num; l++){
						 iToj = points[i].slopeTo(points[j]);
						 iTok = points[i].slopeTo(points[k]);
						 iTol = points[i].slopeTo(points[l]);
						 if(iToj == iTok&&iTok == iTol)
						 {
							 LineSegment lineSeg = new LineSegment(points[i],points[l]);
							 lineList.add(lineSeg);
						 }
					 }
				 }
			 }
		 }

	 }
	 public  int numberOfSegments()        // the number of line segments
	 {
		 return lineList.size();
	 }
	 public LineSegment[] segments()                // the line segments
	 {
		 LineSegment[] segments = new LineSegment[lineList.size()];
		 return lineList.toArray(segments);
	 }
	public static void main(String[] args) {

		// read the n points from a file
		In in = new In(args[0]);
		int n = in.readInt();
		Point[] points = new Point[n];
		for (int i = 0; i < n; i++) {
			int x = in.readInt();
			int y = in.readInt();
			points[i] = new Point(x, y);
		}

		// draw the points
		StdDraw.enableDoubleBuffering();
		StdDraw.setXscale(0, 32768);
		StdDraw.setYscale(0, 32768);
		StdDraw.setPenRadius(0.01);
		for (Point p : points) {
			p.draw();
		}
		StdDraw.show();

		// print and draw the line segments
		StdDraw.setPenColor(StdDraw.BLUE);
		StdDraw.setPenRadius(0.001);
		BruteCollinearPoints collinear = new BruteCollinearPoints(points);
		for (LineSegment segment : collinear.segments()) {
			StdOut.println(segment);
			segment.draw();
		}
		StdDraw.show();
	}

}
