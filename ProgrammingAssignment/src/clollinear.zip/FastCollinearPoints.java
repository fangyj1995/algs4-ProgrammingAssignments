import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.*;

public class FastCollinearPoints {
	private final Point[] points;
	private int num;
	private final ArrayList<LineSegment> lineList;
	/*
	* Test 3a: Points from a file with vertical line segments
	* Test 3b: Random vertical line segments
	* Test 5a: Points from a file with 5 or more on some line segments
	* */
	private static class Line implements Comparable<Line>{
		private double slope;
		private Point point;
        @Override
        public int compareTo(Line that) {
            int slopeCmp = Double.compare(this.slope , that.slope);
            if(slopeCmp != 0)
                return slopeCmp;
            if(Double.compare(slope , this.point.slopeTo(that.point)) == 0)
                return 0;
            return this.point.compareTo(that.point);
        }

        public Line (double slope, Point point){
			this.slope = slope;
			this.point = point;
		}

	}

	public FastCollinearPoints(Point[] p)     // finds all line segments containing 4 or more points
	{
		if(p == null) throw new java.lang.NullPointerException();
		num = p.length;
		this.points = new Point[num];

		for(int i = 0; i< num; i++){
			if(p[i] == null)  throw new java.lang.NullPointerException();
			points[i] = p[i];
		}

		Arrays.sort(points);
		for(int i = 1; i< num; i++){
			if(points[i].compareTo(points[i-1])==0)  throw new java.lang.IllegalArgumentException();
		}

		lineList = new ArrayList<LineSegment>();
		TreeSet<Line> set = new TreeSet<Line>();
		for(int i = 0; i< num - 1; i++) {
			//Arrays.sort(points,i, num);
			Point origin = points[i];
			Arrays.sort(points, i + 1, num, origin.slopeOrder());
			//System.out.println(Arrays.toString(Arrays.copyOfRange(points, i, num)));
			int count = 1, j = i + 1;
			Point s, e;
			if (points[j].compareTo(origin) < 0) {
				s = points[j];
				e = origin;
			} else {
				s = origin;
				e = points[j];
			}
			double slope = s.slopeTo(e);

			for (j = i + 2; j < num; j++) {
				double tempSlope = origin.slopeTo(points[j]);
				if (Double.compare(tempSlope, slope) == 0) {
					if (points[j].compareTo(s) < 0) s = points[j];
					else if (points[j].compareTo(e) > 0) e = points[j];
					count++;
				}
				else {
					if (count >= 3) {
						//System.out.println(s +" -> "+ e);
						Line line = new Line(slope, s);
						if (!set.contains(line)) {
							set.add(line);
							lineList.add(new LineSegment(s, e));
						}
					}

					if (points[j].compareTo(origin) < 0) {
						s = points[j];
						e = origin;
					} else {
						s = origin;
						e = points[j];
					}

					count = 1;
					slope = tempSlope;
				}
			}

			if (count >= 3) {
				//System.out.println(s +" -> "+ e);
				Line line = new Line(slope, s);
				if (!set.contains(line)) {
					set.add(line);
					lineList.add(new LineSegment(s, e));
				}
			}

		}
	}

	public   int numberOfSegments()        // the number of line segments
	{
		 return lineList.size();
	}
	 public LineSegment[] segments()                // the line segments
	 {
		 LineSegment[] segments = new LineSegment[lineList.size()];
		 return lineList.toArray(segments);
	 }
	public static void main(String[] args) {

		// read the n points from a file
		In in = new In(args[0]);
		int n = in.readInt();
		Point[] points = new Point[n];
		for (int i = 0; i < n; i++) {
			int x = in.readInt();
			int y = in.readInt();
			points[i] = new Point(x, y);
		}

		// draw the points
		StdDraw.enableDoubleBuffering();
		StdDraw.setXscale(0, 32768);
		StdDraw.setYscale(0, 32768);
		StdDraw.setPenRadius(0.005);
		for (Point p : points) {
			p.draw();
		}
		StdDraw.show();

		// print and draw the line segments
		StdDraw.setPenColor(StdDraw.BLUE);
		StdDraw.setPenRadius(0.001);
		FastCollinearPoints collinear = new FastCollinearPoints(points);
		for (LineSegment segment : collinear.segments()) {
			StdOut.println(segment);
			segment.draw();
		}
		StdDraw.show();
	}

}
